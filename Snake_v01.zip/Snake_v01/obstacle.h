#ifndef OBSTACLE_H
#define OBSTACLE_H

#include <QGraphicsRectItem>

class Obstacle: public QGraphicsRectItem
{
public:
    Obstacle(QGraphicsItem* parent=NULL);

};


#endif // OBSTACLE_H
